#pragma once
#include"MainFrm.h"
#include"newMESHDoc.h"
#include"newMESHView.h"
#include "ChildFrm.h"
#include"Mesh.h"
// CDialogView ������ͼ

class CDialogView : public CFormView
{
	DECLARE_DYNCREATE(CDialogView)

protected:
	CDialogView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CDialogView();

public:
	enum { IDD = IDD_FORMVIEW };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	double m_AlPha;
	double m_Beta;
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	double m_r;
	afx_msg void OnAddNoise();
	afx_msg void OnMesh();
public:
	vector<vertex>V;vector<vertex>N;vector<face>F;
	CnewMESHView *GetView();
	afx_msg void OnAlmMeshSmoothing();
//	afx_msg void OnEnChangeEdit4();
	double m_temp;
	vector<double> noiseVx,noiseVy,noiseVz;

	double m_sigma;
//	afx_msg void OnBnClickedButton1();
	afx_msg void OnNoiseButton();
	afx_msg void OnNoNoiseMesh();
	afx_msg void OnResultMesh();
	
//	int m_vNumbers;
	//afx_msg void OnButton7();
	//afx_msg void OnFaceButton8();
//	int m_nFaces;
	//afx_msg void OnTVhistogram();
	//afx_msg void OnfidelityEnergy();
	//afx_msg void OnEnChangeEdit8();
	double m_nIdex;

	afx_msg void OnColorMap();
	afx_msg void OnDrawMeshLine();
	afx_msg void OnColorMap1();
//	CEdit m_rq;
	double m_q;
	double m_v1;
	double m_v2;
//	CEdit m_v0;
	double m_v0;
	afx_msg void OnComputeInitial();
};


