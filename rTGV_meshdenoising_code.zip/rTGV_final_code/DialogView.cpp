// DialogView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "newMESH.h"
//#include"newMESHDoc.h"
#include "DialogView.h"
#

// CDialogView

IMPLEMENT_DYNCREATE(CDialogView, CFormView)

CDialogView::CDialogView()
	: CFormView(CDialogView::IDD)
{

	m_AlPha = 0.0;
	m_Beta = 0.0;
	m_r = 0.0;
	m_temp = 0.0;
	m_sigma = 0.0;

	m_q = 0.0;
	m_v1 = 0.0;
	m_v2 = 0.0;
	m_v0 = 0.0;
}
CnewMESHView * CDialogView::GetView()
{
    CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
	CView *pView = (CView *) pChild->m_wndSplitter.GetPane(0, 1);
		
	return (CnewMESHView *)pView;  
}

CDialogView::~CDialogView()
{
}

void CDialogView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_AlPha);
	DDX_Text(pDX, IDC_EDIT2, m_Beta);

	DDX_Text(pDX, IDC_EDIT3, m_r);
	DDX_Text(pDX, IDC_EDIT4, m_temp);
	DDX_Text(pDX, IDC_EDIT5, m_sigma);

	//  DDX_Control(pDX, IDC_EDIT8, m_rq);
	DDX_Text(pDX, IDC_EDIT8, m_q);
	DDX_Text(pDX, IDC_EDIT6, m_v1);
	DDX_Text(pDX, IDC_EDIT7, m_v2);
	//  DDX_Control(pDX, IDC_EDIT9, m_v0);
	DDX_Text(pDX, IDC_EDIT9, m_v0);
}

BEGIN_MESSAGE_MAP(CDialogView, CFormView)

	ON_WM_ACTIVATE()

ON_BN_CLICKED(IDC_BUTTON2, &CDialogView::OnAddNoise)

ON_BN_CLICKED(IDC_BUTTON4, &CDialogView::OnMesh)

ON_BN_CLICKED(IDC_BUTTON3, &CDialogView::OnAlmMeshSmoothing)
ON_BN_CLICKED(IDC_BUTTON1, &CDialogView::OnNoiseButton)
ON_BN_CLICKED(IDC_BUTTON5, &CDialogView::OnNoNoiseMesh)
ON_BN_CLICKED(IDC_BUTTON6, &CDialogView::OnResultMesh)


ON_BN_CLICKED(IDC_BUTTON7, &CDialogView::OnColorMap)
ON_BN_CLICKED(IDC_BUTTON8, &CDialogView::OnDrawMeshLine)
ON_BN_CLICKED(IDC_BUTTON9, &CDialogView::OnColorMap1)
ON_BN_CLICKED(IDC_BUTTON10, &CDialogView::OnComputeInitial)
END_MESSAGE_MAP()


// CDialogView ���

#ifdef _DEBUG
void CDialogView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CDialogView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CDialogView ��Ϣ��������

void CDialogView::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CFormView::OnActivate(nState, pWndOther, bMinimized);

	// TODO: �ڴ˴�������Ϣ�����������
}


void CDialogView::OnAddNoise()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	        UpdateData(true);
	        CnewMESHView *pView=GetView();
			ASSERT_VALID(pView);
	    //   pView->MenuButton=IDC_BUTTON2;
			noiseVx.clear(); noiseVy.clear(); noiseVz.clear();
			pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
			pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
		
			pView->noiseVx.clear();pView->noiseVy.clear();pView->noiseVz.clear();
			pView->noiseNx.clear();pView->noiseNy.clear();pView->noiseNz.clear();
	

			pView->Vx.resize(pView->vNumber);pView->Vy.resize(pView->vNumber);pView->Vz.resize(pView->vNumber);
			pView->Nx.resize(pView->fNumber);pView->Ny.resize(pView->fNumber);pView->Nz.resize(pView->fNumber);
	
			pView->noiseVx.resize(pView->vNumber);pView->noiseVy.resize(pView->vNumber);pView->noiseVz.resize(pView->vNumber);
			pView->noiseNx.resize(pView->fNumber);pView->noiseNy.resize(pView->fNumber);pView->noiseNz.resize(pView->fNumber);
	

		    pView->maxx=-1000;pView->maxy=-1000;pView->maxz=-1000;
	        pView->minx=1000;pView->miny=1000;pView->minz=1000;
			vector<int> vIndex_impulsive; vector<int> v_flag; v_flag.resize(pView->vNumber,0);
		    for(int i = 0; i < pView->vNumber*0.3; i++)
			{
				int vIndex = rand()%(pView->vNumber);
				vIndex_impulsive.push_back(vIndex);
				v_flag[vIndex] = -1;
			}
		    vertex v,normal;double norNormal;
			pView->Mmesh.mesh.update_normals();
		for(MyMesh::VertexIter v_it=pView->Mmesh.mesh.vertices_begin();			
			v_it!=pView->Mmesh.mesh.vertices_end();++v_it)
		{ 
			int vIndex=v_it.handle().idx();double temp;
			//if((vIndex) %5 != 2)
			// temp = 0;
			//else temp = pView->Mmesh.GaussianRandom();
		//	if(v_flag[vIndex] == -1) 
		//		temp = pView->Mmesh.GaussianRandom();
		//	else temp = 0;
			norNormal=sqrt(pView->Mmesh.mesh.normal(v_it)[0]*pView->Mmesh.mesh.normal(v_it)[0]+
				           pView->Mmesh.mesh.normal(v_it)[1]*pView->Mmesh.mesh.normal(v_it)[1]+
						   pView->Mmesh.mesh.normal(v_it)[2]*pView->Mmesh.mesh.normal(v_it)[2]);
			normal.x=pView->Mmesh.mesh.normal(v_it)[0]/norNormal;
			normal.y=pView->Mmesh.mesh.normal(v_it)[1]/norNormal;
			normal.z=pView->Mmesh.mesh.normal(v_it)[2]/norNormal;
			temp = pView->Mmesh.GaussianRandom();
			pView->Mmesh.mesh.point(v_it)[0]+=m_sigma*temp*pView->averageEdge;
			temp = pView->Mmesh.GaussianRandom();
			pView->Mmesh.mesh.point(v_it)[1]+=m_sigma*temp*pView->averageEdge;
			temp = pView->Mmesh.GaussianRandom();
			pView->Mmesh.mesh.point(v_it)[2]+=m_sigma*temp*pView->averageEdge;
			if(pView->maxx<pView->Mmesh.mesh.point(v_it)[0])pView->maxx=pView->Mmesh.mesh.point(v_it)[0];
			if(pView->maxy<pView->Mmesh.mesh.point(v_it)[1])pView->maxy=pView->Mmesh.mesh.point(v_it)[1];
			if(pView->maxz<pView->Mmesh.mesh.point(v_it)[2])pView->maxz=pView->Mmesh.mesh.point(v_it)[2];
			if(pView->minx>pView->Mmesh.mesh.point(v_it)[0])pView->minx=pView->Mmesh.mesh.point(v_it)[0];
			if(pView->miny>pView->Mmesh.mesh.point(v_it)[1])pView->miny=pView->Mmesh.mesh.point(v_it)[1];
			if(pView->minz>pView->Mmesh.mesh.point(v_it)[2])pView->minz=pView->Mmesh.mesh.point(v_it)[2];
			
		
			pView->Vx[vIndex]=pView->Mmesh.mesh.point(v_it)[0];
			pView->Vy[vIndex]=pView->Mmesh.mesh.point(v_it)[1];
			pView->Vz[vIndex]=pView->Mmesh.mesh.point(v_it)[2];
		
		}
	//	pView->length = sqrt((pView->maxx-pView->minx)*(pView->maxx-pView->minx)+(pView->maxy-pView->miny)*(pView->maxy-pView->miny)+(pView->maxz-pView->minz)*(pView->maxz-pView->minz));
		noiseVx = pView->Vx; noiseVy = pView->Vy; noiseVz = pView->Vz;  
		pView->noiseVz = pView->Vz; pView->noiseVy = pView->Vy; pView->noiseVx = pView->Vx;

		pView->Mmesh.mesh.update_normals();
		face Face;
		for(MyMesh::FaceIter f_it=pView->Mmesh.mesh.faces_begin();f_it!=pView->Mmesh.mesh.faces_end();++f_it)
		{
			int fIndex = f_it.handle().idx();
			
			MyMesh::FaceVertexIter fv_it=pView->Mmesh.mesh.fv_iter(f_it.handle());
			vertex a,b,c,v;
		    fv_it;
			a.x=pView->Mmesh.mesh.point(fv_it)[0];a.y=pView->Mmesh.mesh.point(fv_it)[1];a.z=pView->Mmesh.mesh.point(fv_it)[2];
		    (++fv_it);
			b.x=pView->Mmesh.mesh.point(fv_it)[0];b.y=pView->Mmesh.mesh.point(fv_it)[1];b.z=pView->Mmesh.mesh.point(fv_it)[2];
	        (++fv_it);
			c.x=pView->Mmesh.mesh.point(fv_it)[0];c.y=pView->Mmesh.mesh.point(fv_it)[1];c.z=pView->Mmesh.mesh.point(fv_it)[2];
			v=pView->Mmesh.faceNomal(a,b,c);
			pView->Nx[fIndex] = v.x; pView->Ny[fIndex] = v.y; pView->Nz[fIndex] = v.z;
		}
		 try {    if ( !OpenMesh::IO::write_mesh(pView->Mmesh.mesh, "noise_mesh.off") )   
	 {       
		 std::cerr << "Cannot write mesh to file 'outputnoise.off'" << std::endl;   

	 }   }  
	 catch( std::exception& x )  
	 {    
		 std::cerr << x.what() << std::endl;    

	 }
		pView->noisefNormalx = pView->Nx; pView->noisefNormaly = pView->Ny; pView->noisefNormalz = pView->Nz;
		pView->noiseNz = pView->Nz; pView->noiseNy = pView->Ny; pView->noiseNx = pView->Nx;
	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();

}

void CDialogView::OnMesh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();

	pView->Vx=pView->oldVx; pView->Vy=pView->oldVy; pView->Vz=pView->oldVz;
	pView->Nx=pView->oldNx; pView->Ny=pView->oldNy; pView->Nz=pView->oldNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}



void CDialogView::OnAlmMeshSmoothing()
{
	UpdateData(true);
	CnewMESHView *pView=GetView();
   
	pView->almSmoothing(m_AlPha,m_q,m_Beta,m_r,m_temp,m_v0,m_v1,m_v2);

	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
	
	cout<<"dialogview"<<endl;
	
	pView->Vx=pView->newVx; pView->Vy=pView->newVy; pView->Vz=pView->newVz;
	pView->Nx=pView->newNx; pView->Ny=pView->newNy; pView->Nz=pView->newNz;

	cout<<"afterdialogview"<<endl;
	 int k=0;
	for(MyMesh::VertexIter v_it=pView->Mmesh.mesh.vertices_begin();			
			v_it!=pView->Mmesh.mesh.vertices_end();++v_it)
	{
		pView->Mmesh.mesh.point(v_it)[0]=noiseVx[k];
		pView->Mmesh.mesh.point(v_it)[1]=noiseVy[k];
		pView->Mmesh.mesh.point(v_it)[2]=noiseVz[k];
		k++;
	}
	 CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}

void CDialogView::OnNoiseButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
	
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();

	pView->Mmesh.flags = 0; pView->Mmesh.meshflags = 0;
	pView->Vx=pView->noiseVx; pView->Vy=pView->noiseVy; pView->Vz=pView->noiseVz;
	pView->Nx=pView->noiseNx; pView->Ny=pView->noiseNy; pView->Nz=pView->noiseNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
	   
}


void CDialogView::OnNoNoiseMesh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
   

	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
	//pView->Fa.clear();pView->Fb.clear();pView->Fc.clear();	
	pView->Mmesh.flags = 0; pView->Mmesh.meshflags = 0;
	pView->Vx=pView->oldVx; pView->Vy=pView->oldVy; pView->Vz=pView->oldVz;
	pView->Nx=pView->oldNx; pView->Ny=pView->oldNy; pView->Nz=pView->oldNz;

	 int k=0;
	for(MyMesh::VertexIter v_it=pView->Mmesh.mesh.vertices_begin();			
			v_it!=pView->Mmesh.mesh.vertices_end();++v_it)
	{
		pView->Mmesh.mesh.point(v_it)[0]=pView->oldVx[k];
		pView->Mmesh.mesh.point(v_it)[1]=pView->oldVy[k];
		pView->Mmesh.mesh.point(v_it)[2]=pView->oldVz[k];
		k++;
	}
	 CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}


void CDialogView::OnResultMesh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
  
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
	pView->Mmesh.flags = 0; pView->Mmesh.meshflags = 0;
	pView->Vx=pView->resultVx; pView->Vy=pView->resultVy; pView->Vz=pView->resultVz;
	pView->Nx=pView->resultNx; pView->Ny=pView->resultNy; pView->Nz=pView->resultNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}




void CDialogView::OnColorMap()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
  
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
//	pView->Mmesh.compute_edge_gradient();
	cout<<"compute end"<<endl;
	pView->Mmesh.flags = 0; pView->Mmesh.meshflags = 1; pView->Mmesh.meshline = 0;
	pView->Vx=pView->resultVx; pView->Vy=pView->resultVy; pView->Vz=pView->resultVz;
	pView->Nx=pView->resultNx; pView->Ny=pView->resultNy; pView->Nz=pView->resultNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}


void CDialogView::OnDrawMeshLine()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
  
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();

	pView->Mmesh.flags = 0; pView->Mmesh.meshflags = 0; pView->Mmesh.meshline = 1;
	pView->Vx=pView->resultVx; pView->Vy=pView->resultVy; pView->Vz=pView->resultVz;
	pView->Nx=pView->resultNx; pView->Ny=pView->resultNy; pView->Nz=pView->resultNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}


void CDialogView::OnColorMap1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CnewMESHView *pView=GetView();
  
	pView->Vx.clear();pView->Vy.clear();pView->Vz.clear();
	pView->Nx.clear();pView->Ny.clear();pView->Nz.clear();
//	pView->Mmesh.compute_triangle_gradient();
	pView->Mmesh.flags = 1; pView->Mmesh.meshflags = 0; pView->Mmesh.meshline = 0;
	pView->Vx=pView->resultVx; pView->Vy=pView->resultVy; pView->Vz=pView->resultVz;
	pView->Nx=pView->resultNx; pView->Ny=pView->resultNy; pView->Nz=pView->resultNz;

	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}


void CDialogView::OnComputeInitial()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData(true);
	CnewMESHView *pView=GetView();
  	
	 pView->Mmesh.computeTemp();
	 pView->Mmesh.computeMeshCoeff(); 
	
		
	  CnewMESHApp* pApp = (CnewMESHApp *)AfxGetApp();
	  CMainFrame* pFrame = (CMainFrame *)pApp->m_pMainWnd;               
	  CChildFrame *pChild = (CChildFrame *) pFrame->GetActiveFrame();
      pChild->Invalidate();
}
