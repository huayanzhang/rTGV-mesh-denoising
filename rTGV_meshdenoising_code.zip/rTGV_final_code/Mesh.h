#pragma once
#include<iostream>

#include<gmm/gmm.h>
#include<OpenMesh/Core/IO/MeshIO.hh>
#include<OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include"OpenMesh/Core/Mesh/Handles.hh"
//#include "mkl.h"
//#include "mkl_sparse_system/mkl_addon.h"
//#include "mkl_sparse_system/spmatrix.h"
#include <D:\Program Files (x86)\Eigen\Sparse>
#include <D:\Program Files (x86)\Eigen\IterativeLinearSolvers>
#include <D:\Program Files (x86)\Eigen\SparseCholesky>
#include <D:\Program Files (x86)\Eigen\Dense>
typedef OpenMesh::TriMesh_ArrayKernelT<> MyMesh;
typedef gmm::row_matrix<gmm::wsvector<double>> RowSparseMatrix;
typedef gmm::dense_matrix<double>DenseMatrix;
typedef Eigen::Triplet<double>T;
using namespace Eigen;
using namespace std;
struct vertex{
	double x;double y;double z;
	int degree;
	vector<int>v_FaceIndex;	
	vector<int>v_vertexIndex;
 };

struct face{
	int a;int b;int c;

	vector<int>eIndex;
	vector<int>flags;
	vector<int>fIndex;
	vector<int>ffIndex;
};
struct edge{
	int v1_index;
	int v2_index; 
	int findex[2];
	double eLength;
	int fflags[2];
	int vIndex[2];
	int flag;
	int f_flag;
   
};

class Mesh
{
public:
	Mesh(void);
	~Mesh(void);
	void readMeshFile(const string & filename);
	MyMesh mesh;
	void almMeshSmoothing(double alpha1,double alpha0,double beta,double rp,double rq,double v0,double v1,double v2);
	void computeMeshCoeff(void);
	std::vector<double> faceArea_;
	vector<double> Vx,Vy,Vz;
	vector<double> Nx,Ny,Nz;
	double maxx,minx,maxy,miny,maxz,minz;
    int eNumber,vNumber,fNumber;
	DenseMatrix featureDatas_;
	void addGaussianNoise(int eigIndex,double variance);
	double GaussianRandom(void);
	double triangleSurfaceArea(const vertex & pointA, const vertex &pointB, const vertex & pointC);
	
	void output(void);
	vertex faceNomal(vertex a,vertex b,vertex c);
    void computeTemp(void);
	vector<edge> Edges;
	vector<vertex> Points;
	vector<double> Fnormalx,Fnormaly,Fnormalz;
	vector<face> Faces;
	void UpdateVertex();	
	void nProblemsolver1(double beta, double r,
	                      std::vector<double>&lamda_x,
						  std::vector<double>&lamda_y,
						  std::vector<double>&lamda_z,
						  std::vector<double>&px,
						  std::vector<double>&py,
						  std::vector<double>&pz,
						  vector<double>&normalx, vector<double>&normaly, vector<double>&normalz,
						 Eigen::VectorXd &matF_X,
						 Eigen::VectorXd &matF_Y,
						 Eigen::VectorXd &matF_Z,
						 vector<double> &vx, vector<double>vy,vector<double>vz);
	void matrix_A(double beta, double r,SparseMatrix<double> &mat_X);
	void pProblem(double alpha1,double r, std::vector<double>&grad0,
						std::vector<double>&grad1,
						std::vector<double>&grad2,
						std::vector<double>&lambda_x,
						std::vector<double>&lambda_y,
						std::vector<double>&lambda_z,
						vector<double>&vx,
						vector<double>&vy,
						vector<double>&vz,
						std::vector<double>&px,
						std::vector<double>&py,
						std::vector<double>&pz,
						std::vector<double>&nx,
						std::vector<double>&ny,
						std::vector<double>&nz);
	vector<double>nxx,nyy,nzz;
	vector<double>vxx,vyy,vzz;
	
	void OurDenoisingMethod(double alpha1,double alpha0, double rp ,double rq, double beta, vector<double>&normalx,vector<double>&normaly,vector<double>&normalz);
	
	int flags, meshflags;
	double TriangleArea(double *p1,double *p2,double *p3);
	
	int meshline;
	void matrix_V(double rp,double rq,SparseMatrix<double> &mat_V,vector<double>&normalx, vector<double>&normaly, vector<double>&normalz,vector<double>&weight);
	void compute_basis_normal(vector<double>& enx, vector<double>&eny, vector<double>&enz);
	void Vb(double rp, double rq, vector<double>&px,vector<double>&py,vector<double>&pz,vector<double>&nx,vector<double>&ny,vector<double>&nz,
						 vector<double>&lambda_px,vector<double>&lambda_py,vector<double>&lambda_pz,
						 vector<double>&gradx,vector<double>&grady, vector<double>&gradz,
						 vector<double>&qx,vector<double>&qy,vector<double>&qz,
						 vector<double>&lambda_qx,vector<double>&lambda_qy,vector<double>&lambda_qz,
						  Eigen::VectorXd &bx,  Eigen::VectorXd &by,  Eigen::VectorXd &bz,
						  vector<double>&weight);
	void q_subproblem(double alpha0, double rq, vector<double> &div_x,vector<double> &div_y,vector<double> &div_z,
	                     vector<double>&qx,vector<double> &qy,vector<double>&qz,
						 vector<double>&lambda_qx,vector<double> &lambda_qy,vector<double> &lambda_qz,
						 vector<double>&vx, vector<double>&vy,vector<double>&vz,vector<double>&nx, vector<double>&ny,vector<double>&nz,vector<double>&weight);
	void new_updating_vertex(double v0,double v1, double v2, vector<double>&initial_x, vector<double>&initial_y, vector<double>& initial_z);
	void matrix_vertex(double r,double alpha, double beta,SparseMatrix<double >& mat);
	vector<MyMesh::Point> rPositions;

};

