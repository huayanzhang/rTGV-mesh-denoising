
// ChildFrm.cpp : CChildFrame ���ʵ��
//

#include "stdafx.h"
#include "newMESH.h"

#include "ChildFrm.h"
#include "DialogView.h"
#include "newMESHView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWndEx)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWndEx)
END_MESSAGE_MAP()

// CChildFrame ����/����

CChildFrame::CChildFrame()
{
	// TODO: �ڴ����ӳ�Ա��ʼ������
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸� CREATESTRUCT cs ���޸Ĵ��������ʽ
	if( !CMDIChildWndEx::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}

// CChildFrame ���

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWndEx::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWndEx::Dump(dc);
}
#endif //_DEBUG

// CChildFrame ��Ϣ��������


BOOL CChildFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	// TODO: �ڴ�����ר�ô����/����û���
		if (!m_wndSplitter.CreateStatic(this, 1, 2, WS_CHILD | WS_VISIBLE))
	{
		TRACE("Failed to CreateStaticSplitter\n");
		return FALSE;
	}
	
	// Determine the width
	OSVERSIONINFO osvi;
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);
	bool bIsWindowsXPorLater = ( (osvi.dwMajorVersion > 5) ||
		( (osvi.dwMajorVersion == 5) && (osvi.dwMinorVersion >= 1) ) );
	int width = 290;
	int cx = ::GetSystemMetrics(SM_CXSCREEN);
	if (cx < 1280 || !bIsWindowsXPorLater)
		width = 200;
	
	// First splitter pane	
	if (!m_wndSplitter.CreateView(0, 0,	RUNTIME_CLASS(CDialogView), CSize(width, 0), pContext))
	{
		TRACE("Failed to create command view pane\n");
		return FALSE;
	}
	
	// Second splitter pane
	if (!m_wndSplitter.CreateView(0, 1,	RUNTIME_CLASS(CnewMESHView), CSize(0, 0), pContext))
	{
		TRACE("Failed to create preview pane\n");
		return FALSE;
	}

     m_wndSplitter.SetActivePane(0,1);
	
	return TRUE;
	return CMDIChildWndEx::OnCreateClient(lpcs, pContext);
}
