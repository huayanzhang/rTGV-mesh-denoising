#include "StdAfx.h"
#include "Mesh.h"
#include <algorithm>
#include <sstream>
#include<math.h>
#include<omp.h>
#define NUM_THREADS 8
Mesh::Mesh(void)
{
	mesh.request_face_colors();
	mesh.request_vertex_colors();
	mesh.request_face_normals();
	mesh.request_vertex_normals();
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	Edges.clear();Points.clear(); Faces.clear();
	Fnormalx.clear(); Fnormaly.clear(); Fnormalz.clear();
	maxx = -1000;maxy = -1000;maxz = -1000;
	minx = 1000; miny = 1000; minz = 1000;
	flags = 0;  meshflags = 0;
}


Mesh::~Mesh(void)
{
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	
	
}




void Mesh::readMeshFile(const string & filename)
{

	if(!OpenMesh::IO::read_mesh(mesh,filename))
	{
		std::cerr<<"read error\n";
		exit(1);
	}

}



void Mesh::almMeshSmoothing(double alpha1,double alpha0,double beta,double rp,double rq,double v0,double v1,double v2)
{
	  cout<<"vNumbers"<<mesh.n_vertices()<<"   fNubmers"<<mesh.n_faces()<<" eNumbers  "<<mesh.n_edges()<<endl;

	 
	  clock_t start,end;
 
	  vNumber = mesh.n_vertices();	fNumber = mesh.n_faces();	eNumber = mesh.n_edges();
	   vector<double> px(vNumber),py(vNumber),pz(vNumber),normalx(fNumber),normaly(fNumber),normalz(fNumber);

	    start = clock();	
		px.clear(); py.clear(); pz.clear();
		normalx.clear(); normaly.clear(); normalz.clear();
        for(MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	    {
		    int vIndex = vIt.handle().idx();
	
		    px[vIndex] = Points[vIndex].x;
		    py[vIndex] = Points[vIndex].y;
		    pz[vIndex] = Points[vIndex].z;
	     }
		
		for(int iter = 0; iter < 1; iter++)
		{
		
			for(int i = 0; i < fNumber; i++)
			{ 
				int a = Faces[i].a;  int b = Faces[i].b; int c = Faces[i].c;
				vertex va,vb,vc,vn;
				va.x = px[a]; va.y = py[a]; va.z = pz[a];
				vb.x = px[b]; vb.y = py[b]; vb.z = pz[b];
				vc.x = px[c]; vc.y = py[c]; vc.z = pz[c];
				vn = faceNomal(va,vb,vc);
				normalx[i] = vn.x; normaly[i] = vn.y; normalz[i] = vn.z;
			}	   
			for(int i = 0; i < eNumber; i++)
			{
				int v1 = Edges[i].v1_index;  int v2 = Edges[i].v2_index;
				Edges[i].eLength = sqrt((px[v1]-px[v2])*(px[v1]-px[v2]) + (py[v1]-py[v2])*(py[v1]-py[v2]) + (pz[v1]-pz[v2])*(pz[v1]-pz[v2]));
			}
			
	        OurDenoisingMethod(alpha1,alpha0,rp,rq,beta,normalx,normaly,normalz);
	        new_updating_vertex(v0,v1,v2,px,py,pz);	   
			beta = 1.5*beta;  v2 = v2*1.3;
		}
	   end = clock();
	 
	cout<<"time:  "<<end-start<<endl;


	 try {    if ( !OpenMesh::IO::write_mesh(mesh, "coupling_output.off") )   
	 {       
		 std::cerr << "Cannot write mesh to file 'outputnoise.off'" << std::endl;   

	 }   }  
	 catch( std::exception& x )  
	 {    
		 std::cerr << x.what() << std::endl;    

	 }
}
void Mesh::computeMeshCoeff(void)
{
	int vNumber=mesh.n_vertices(); int fNumber=mesh.n_faces();
	faceArea_.resize(fNumber);
	mesh.update_normals();                                                                                                                                                                                                                                                                                                                                                

	for (MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		vertex p0,p1,p2;
		MyMesh::FaceVertexIter fv_it = mesh.fv_iter(fIt.handle());
		int v0 = fv_it.handle().idx();     p0.x = mesh.point(fv_it).values_[0];p0.y = mesh.point(fv_it).values_[1];p0.z = mesh.point(fv_it).values_[2];
		int v1 = (++fv_it).handle().idx(); p1.x = mesh.point(fv_it).values_[0];p1.y = mesh.point(fv_it).values_[1];p1.z = mesh.point(fv_it).values_[2];
		int v2 = (++fv_it).handle().idx(); p2.x = mesh.point(fv_it).values_[0];p2.y = mesh.point(fv_it).values_[1];p2.z = mesh.point(fv_it).values_[2];
		faceArea_[fIndex] =triangleSurfaceArea(p0,p1,p2);//每个面的面积
	}

}


void Mesh::addGaussianNoise(int eigIndex,double variance)
{
	int nRow=featureDatas_.nrows();

	for(int i=0;i<nRow;i++)
	{
		featureDatas_(i,eigIndex)+=variance*GaussianRandom();
	}
}

double Mesh::GaussianRandom(void)
{
	double x1,x2,w,y1,y2;
	do
	{
		x1=2.0*double(rand())/RAND_MAX-1.0;
		x2=2.0*double(rand())/RAND_MAX-1.0;
		w=x1*x1+x2*x2;
	}while(w>=1.0);

	w=sqrt((-2.0*log(w))/w);
	y1=x1*w;  y2=x2*w;

	return y1;

}	

double Mesh::triangleSurfaceArea(const vertex & pointA, const vertex &pointB, const vertex & pointC)
{

	double a, b,c;

	a = sqrt((pointA.x-pointB.x)*(pointA.x-pointB.x)+(pointA.y-pointB.y)*(pointA.y-pointB.y)+(pointA.z-pointB.z)*(pointA.z-pointB.z));
	b = sqrt((pointC.x-pointB.x)*(pointC.x-pointB.x)+(pointC.y-pointB.y)*(pointC.y-pointB.y)+(pointC.z-pointB.z)*(pointC.z-pointB.z));
	c = sqrt((pointC.x-pointA.x)*(pointC.x-pointA.x)+(pointC.y-pointA.y)*(pointC.y-pointA.y)+(pointC.z-pointA.z)*(pointC.z-pointA.z));

	double s = .5 * (a+b+c);
	double sqrA = s*(s-a)*(s-b)*(s-c);
	if (sqrA < 0) {
		sqrA = 0;
	}
	return sqrt(sqrA);
}

void Mesh::output(void)
{ 
	int k=0;
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	Vx.resize(mesh.n_vertices()); Vy.resize(mesh.n_vertices()); Vz.resize(mesh.n_vertices());
	Nx.resize(mesh.n_faces()); Ny.resize(mesh.n_faces()); Nz.resize(mesh.n_faces());
	mesh.update_normals();
	for(MyMesh::VertexIter v_it=mesh.vertices_begin();			
		v_it!=mesh.vertices_end();++v_it)
	{
		int vIndex = v_it.handle().idx();
		if(maxx<mesh.point(v_it).values_[0])maxx=mesh.point(v_it)[0];
		if(maxy<mesh.point(v_it).values_[1])maxy=mesh.point(v_it)[1];
		if(maxz<mesh.point(v_it).values_[2])maxz=mesh.point(v_it)[2];
		if(minx>mesh.point(v_it).values_[0])minx=mesh.point(v_it)[0];
		if(miny>mesh.point(v_it).values_[1])miny=mesh.point(v_it)[1];
		if(minz>mesh.point(v_it).values_[2])minz=mesh.point(v_it)[2];

		Vx[vIndex]=mesh.point(v_it)[0];
		Vy[vIndex]=mesh.point(v_it)[1];
		Vz[vIndex]=mesh.point(v_it)[2];

	}
//	cout<<"outface:"<<endl;
	face Face;
	for(MyMesh::FaceIter f_it=mesh.faces_begin();f_it!=mesh.faces_end();++f_it)
	{
		int fIndex = f_it.handle().idx();
		MyMesh::FaceVertexIter fv_it=mesh.fv_iter(f_it.handle());
		vertex a,b,c,v;
		fv_it.handle().idx();
		a.x=mesh.point(fv_it)[0];a.y=mesh.point(fv_it)[1];a.z=mesh.point(fv_it)[2];  
		(++fv_it).handle().idx();
		b.x=mesh.point(fv_it)[0];b.y=mesh.point(fv_it)[1];b.z=mesh.point(fv_it)[2];
		(++fv_it).handle().idx();
		c.x=mesh.point(fv_it)[0];c.y=mesh.point(fv_it)[1];c.z=mesh.point(fv_it)[2];
		v=faceNomal(a,b,c);
		Nx[fIndex] = v.x; Ny[fIndex] = v.y; Nz[fIndex] = v.z;
	
	}

	try  
	{    
		if ( !OpenMesh::IO::write_mesh(mesh, "output.obj") )   
	
		{       std::cerr << "Cannot write mesh to file 'output.off'" << std::endl;   } 
	}  

	catch( std::exception& x )  
	{    
		std::cerr << x.what() << std::endl;    

	}
}

vertex Mesh::faceNomal(vertex a,vertex b,vertex c)
{
	double x,y,z;
	x=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y);
	y=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z);
	z=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);

	double L;
	L=sqrt(x*x+y*y+z*z);
	vertex N;
	N.x=x/L;N.y=y/L;N.z=z/L;

	return N;
}


void Mesh::computeTemp(void)
{
	Edges.clear(); Points.clear(); Faces.clear();
	
	Edges.resize(mesh.n_edges());
	Points.resize(mesh.n_vertices());
	Faces.resize(mesh.n_faces());
	int nedges = 0;
	//存储点的信息
	mesh.update_normals();
	for (MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	{
		const int vIndex = vIt.handle().idx();
		Points[vIndex].v_FaceIndex.clear();
		Points[vIndex].x = mesh.point(vIt)[0];
		Points[vIndex].y = mesh.point(vIt)[1];
		Points[vIndex].z = mesh.point(vIt)[2];
		for(MyMesh::VertexFaceIter vfIt = mesh.vf_begin(vIt); vfIt != mesh.vf_end(vIt); ++vfIt)
		{
			int vvIndex = vfIt.handle().idx();
			Points[vIndex].v_FaceIndex.push_back(vvIndex);
		}
	//	cout<<vIndex<<" "<<Points[vIndex].v_FaceIndex<<endl;
		for(MyMesh::VertexVertexIter vvIt = mesh.vv_begin(vIt); vvIt != mesh.vv_end(vIt); ++vvIt)
		{
			int vvIndex = vvIt.handle().idx();
			Points[vIndex].v_vertexIndex.push_back(vvIndex);
		}
	//	cout<<Points[vIndex].v_vertexIndex<<endl;
//		cout<<vIndex<<endl;
	}
	cout<<Points.size()<<endl;
	cout<<Points[0].x<<"  "<<Points[0].y<<"  "<<Points[0].z<<endl;
	//存储面的信息
	for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		Faces[fIndex].fIndex.clear();
		MyMesh::FaceVertexIter fv_It = mesh.fv_iter(fIt.handle());
		MyMesh::VertexHandle v0 = fv_It; ++fv_It;
    	Faces[fIndex].a = v0.idx(); 
		MyMesh::VertexHandle v1 = fv_It; ++fv_It;
		Faces[fIndex].b = v1.idx();
		MyMesh::VertexHandle v2 = fv_It;
		Faces[fIndex].c = v2.idx(); 
	}
	//cout<<Faces.size()<<endl;
	//存储边的信息 
	double L = 0;
	for(MyMesh::EdgeIter eIt = mesh.edges_begin(); eIt != mesh.edges_end(); ++eIt)
	{
		int eIndex = eIt.handle().idx();
		MyMesh::VertexHandle v0 = mesh.to_vertex_handle(mesh.halfedge_handle(eIt,0));//每条边有两个半边。
		MyMesh::VertexHandle v1 = mesh.to_vertex_handle(mesh.halfedge_handle(eIt,1));
		int v0_Index = v0.idx();
		int v1_Index = v1.idx();
	    BOOL b1 = mesh.is_boundary(eIt); //是否为边界边是为1, 否为0
		if(b1 == 1) Edges[eIndex].flag = -1; else Edges[eIndex].flag = 1;
		MyMesh::FaceHandle f0 = mesh.face_handle(mesh.halfedge_handle(eIt,0));//每条边有两个面。
		MyMesh::FaceHandle f1 = mesh.face_handle(mesh.halfedge_handle(eIt,1));
		BOOL b2 = mesh.is_valid_handle(f0);//是否存在面，存在为1,不存在为0;
		BOOL b3 = mesh.is_valid_handle(f1);
       // cout<<eIndex<<"  "<<b1<<"  "<<b2<<" "<<b3<<endl;
		int f0_Index ,f1_Index;		
	    int f0_a,f0_b,f0_c,f1_a,f1_b,f1_c;
		if(b2 != 0)
		{ 
			f0_Index = f0.idx();Edges[eIndex].findex[0] = f0_Index;
			f0_a = Faces[f0.idx()].a ;  f0_b = Faces[f0.idx()].b;  f0_c = Faces[f0.idx()].c;
		}
		else { f0_Index = -1; Edges[eIndex].findex[0] = f0_Index; }
		if(b3 != 0)
		{
			f1_Index = f1.idx();Edges[eIndex].findex[1] = f1_Index;
			f1_a = Faces[f1.idx()].a ;  f1_b = Faces[f1.idx()].b;  f1_c = Faces[f1.idx()].c;
		}
		else {f1_Index = -1; Edges[eIndex].findex[1] = f1_Index;}
		Edges[eIndex].v1_index = v0_Index;
		Edges[eIndex].v2_index = v1_Index;		                                                                                    
		Edges[eIndex].eLength = 1.*sqrt((Points[v0_Index].x-Points[v1_Index].x)*(Points[v0_Index].x-Points[v1_Index].x)+
			                       (Points[v0_Index].y-Points[v1_Index].y)*(Points[v0_Index].y-Points[v1_Index].y)+
		                        	(Points[v0_Index].z-Points[v1_Index].z)*(Points[v0_Index].z-Points[v1_Index].z));
		if(f0_a != v0_Index && f0_a != v1_Index)
			Edges[eIndex].vIndex[0] = f0_a;
		if(f0_b != v0_Index && f0_b != v1_Index)
			Edges[eIndex].vIndex[0] = f0_b;
		if(f0_c != v0_Index && f0_c != v1_Index)
			Edges[eIndex].vIndex[0] = f0_c;

		if(f1_a != v0_Index && f1_a != v1_Index)
			Edges[eIndex].vIndex[1] = f1_a;
		if(f1_b != v0_Index && f1_b != v1_Index)
			Edges[eIndex].vIndex[1] = f1_b;
		if(f1_c != v0_Index && f1_c != v1_Index)
			Edges[eIndex].vIndex[1] = f1_c;
		//cout<<Edges[eIndex].vIndex[0]<<"   "<<Edges[eIndex].vIndex[1]<<"  "<<v0_Index<<"  "<<v1_Index<<endl;
		L += Edges[eIndex].eLength;
		if(f0_Index!=-1 &&f1_Index != -1)
		{
		if((Edges[eIndex].v1_index== f0_a &&Edges[eIndex].v2_index ==f0_b)||(Edges[eIndex].v1_index== f0_b &&Edges[eIndex].v2_index ==f0_c)||(Edges[eIndex].v1_index== f0_c &&Edges[eIndex].v2_index ==f0_a))
			Edges[eIndex].fflags[0] = 1;
		else 
			Edges[eIndex].fflags[0] = -1;
		Edges[eIndex].fflags[1] = -Edges[eIndex].fflags[0];
		}
		else
		{
			if(f0_Index = -1)
			{
			    if((Edges[eIndex].v1_index== f1_a &&Edges[eIndex].v2_index ==f1_b)||(Edges[eIndex].v1_index== f1_b &&Edges[eIndex].v2_index ==f1_c)||(Edges[eIndex].v1_index== f1_c &&Edges[eIndex].v2_index ==f1_a))
			      Edges[eIndex].fflags[1] = 1;
		       else 
			      Edges[eIndex].fflags[1] = -1;
                  Edges[eIndex].fflags[0] = 0;
			}
			if(f1_Index = -1)
			{
			    if((Edges[eIndex].v1_index== f0_a &&Edges[eIndex].v2_index ==f0_b)||(Edges[eIndex].v1_index== f0_b &&Edges[eIndex].v2_index ==f0_c)||(Edges[eIndex].v1_index== f0_c &&Edges[eIndex].v2_index ==f0_a))
			      Edges[eIndex].fflags[0] = 1;
		       else 
			      Edges[eIndex].fflags[0] = -1;
                  Edges[eIndex].fflags[1] = 0;
			}
		}

	}
	L = L/eNumber;// cout<<" L : "<<L<<endl;
	//存储面的信息
	for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();	
		Faces[fIndex].eIndex.clear();
		Faces[fIndex].flags.clear();
		for(MyMesh::FaceEdgeIter fe_It = mesh.fe_begin(fIt); fe_It != mesh.fe_end(fIt); ++fe_It)
		{
			int feIndex = fe_It.handle().idx();//边的标号
			Faces[fIndex].eIndex.push_back(feIndex);
			MyMesh::FaceHandle f0 = mesh.face_handle(mesh.halfedge_handle(fe_It,0));//每条边有两个面。
		    MyMesh::FaceHandle f1 = mesh.face_handle(mesh.halfedge_handle(fe_It,1));
			int fa = f0.idx(); int fb = f1.idx();
			if(Edges[feIndex].flag == -1) Faces[fIndex].fIndex.push_back(-1);
			else{
				if(fa != fIndex) Faces[fIndex].fIndex.push_back(fa);
				else Faces[fIndex].fIndex.push_back(fb);
			 }
			int v0 = Edges[feIndex].v1_index; 
			int v1 = Edges[feIndex].v2_index;
			if((v0 == Faces[fIndex].a &&v1 ==Faces[fIndex].b)||(v0 == Faces[fIndex].b &&v1 ==Faces[fIndex].c)||(v0 == Faces[fIndex].c &&v1 ==Faces[fIndex].a))
				Faces[fIndex].flags.push_back(1);
			else 
				Faces[fIndex].flags.push_back(-1);
		}

	}
	//faceneighbor();
	
}



void Mesh::UpdateVertex()
{
//定义变量及分配空间
	vector<double> newPoints_x,newPoints_y,newPoints_z; 
	newPoints_x.resize(mesh.n_vertices()); newPoints_y.resize(mesh.n_vertices()); newPoints_z.resize(mesh.n_vertices());
	vector<double> oldVertex_x,oldVertex_y,oldVertex_z; 
	oldVertex_x.resize(mesh.n_vertices()); oldVertex_y.resize(mesh.n_vertices()); oldVertex_z.resize(mesh.n_vertices());

    //存储点的一邻域的三角形（one_disk）
	for (MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	{
		const int vIndex = vIt.handle().idx();		
		for(MyMesh::VertexFaceIter vfIt = mesh.vf_begin(vIt); vfIt != mesh.vf_end(vIt); ++vfIt)
		{
			int vvIndex = vfIt.handle().idx();
			Points[vIndex].v_FaceIndex.push_back(vvIndex);
		}	
	}
	//变量赋初值
	for (int i = 0; i < mesh.n_vertices(); i++)
	{
		newPoints_x[i] = Points[i].x;
		newPoints_y[i] = Points[i].y;
		newPoints_z[i] = Points[i].z;
	
	}
	//迭代开始
	for(int k = 0; k< 40; k++)
	{
		//存储上一层点的坐标值;
	    for( int i = 0; i< mesh.n_vertices(); i++)
	    {
		    oldVertex_x[i] = newPoints_x[i];
		    oldVertex_y[i] = newPoints_y[i];
		    oldVertex_z[i] = newPoints_z[i];
	    }
		//遍历网格所有点
		for (int i = 0; i < mesh.n_vertices(); i++)
	    {	
			vertex v,point;  
			v.x = oldVertex_x[i]; v.y = oldVertex_y[i]; v.z = oldVertex_z[i];	 //点的坐标值  
			point.x = 0; point.y = 0; point.z = 0;
			//遍历点i的one_disk里的三角形
			for(int k = 0; k < Points[i].v_FaceIndex.size(); k++ ) 
		    {
				int vfIndex = Points[i].v_FaceIndex[k];//one_disk中三角形的标号
				int v1,v2,v3;  //三角形的三个点的标号
				vertex c, normal;  
				v1 = Faces[vfIndex].a; v2 = Faces[vfIndex].b; v3 = Faces[vfIndex].c;
				//三角形的法向
				normal.x = Fnormalx[vfIndex]; normal.y = Fnormaly[vfIndex]; normal.z = Fnormalz[vfIndex];	
				//三角形的重心坐标
		        c.x = (oldVertex_x[v1]+oldVertex_x[v2]+oldVertex_x[v3])/3;
			    c.y = (oldVertex_y[v1]+oldVertex_y[v2]+oldVertex_y[v3])/3;
			    c.z = (oldVertex_z[v1]+oldVertex_z[v2]+oldVertex_z[v3])/3;
			    double temp = normal.x*(c.x-v.x)+normal.y*(c.y-v.y)+normal.z*(c.z-v.z);
		        point.x += normal.x*temp;
			    point.y += normal.y*temp;
			    point.z += normal.z*temp;	   
		      }
			//计算新的点的位置
			   newPoints_x[i] += point.x/Points[i].v_FaceIndex.size();  
			   newPoints_y[i] += point.y/Points[i].v_FaceIndex.size(); 
			   newPoints_z[i] += point.z/Points[i].v_FaceIndex.size();	
	   }
	
  }
	for(MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it!= mesh.vertices_end(); ++v_it)
	{
		int vIndex = v_it.handle().idx();
		mesh.point(v_it)[0] = newPoints_x[vIndex];
		mesh.point(v_it)[1] = newPoints_y[vIndex];
		mesh.point(v_it)[2] = newPoints_z[vIndex];
	}

	newPoints_x.clear(); newPoints_y.clear(); newPoints_z.clear();
	oldVertex_x.clear(); oldVertex_y.clear(); oldVertex_z.clear();
}



void Mesh::nProblemsolver1(double beta, double r,
	                      std::vector<double>&lamda_x,
						  std::vector<double>&lamda_y,
						  std::vector<double>&lamda_z,
						  std::vector<double>&px,
						  std::vector<double>&py,
						  std::vector<double>&pz,
						 vector<double>&normalx, vector<double>&normaly, vector<double>&normalz,
						 Eigen::VectorXd &matF_X,
						 Eigen::VectorXd &matF_Y,
						 Eigen::VectorXd &matF_Z,
						 vector<double> &vx, vector<double>vy,vector<double>vz)
{
	int dimension = mesh.n_faces();
	int rows = dimension;

	for(int k = 0; k < dimension; k++)
	{
		int fIndex = k; 
		
		matF_X[fIndex] = beta*faceArea_[fIndex]*normalx[fIndex];
		matF_Y[fIndex] = beta*faceArea_[fIndex]*normaly[fIndex];
		matF_Z[fIndex] = beta*faceArea_[fIndex]*normalz[fIndex];

		for(int i = 0; i < 3; i++)
		{
			int feIndex = Faces[fIndex].eIndex[i];//面的三条边的标号
			int fflags = Faces[fIndex].flags[i];//边与面的方向标号
			double e_Length = Edges[feIndex].eLength;//边的长度
			 if(Edges[feIndex].flag != -1)
			 {
				matF_X[fIndex] += (lamda_x[feIndex]+r*px[feIndex]+r*vx[feIndex])*fflags*e_Length;
			    matF_Y[fIndex] += (lamda_y[feIndex]+r*py[feIndex]+r*vy[feIndex])*fflags*e_Length;
			    matF_Z[fIndex] += (lamda_z[feIndex]+r*pz[feIndex]+r*vz[feIndex])*fflags*e_Length;
			 }
			 else
			 { 
				 matF_X[fIndex] += 0;
			     matF_Y[fIndex] += 0;
	             matF_Z[fIndex] += 0;
			 }

		}
		
	}
}

void Mesh::matrix_A(double beta,double r,SparseMatrix<double> &mat_X)
{
	int dimension = mesh.n_faces();
	int rows = dimension;
	
	mat_X.reserve(VectorXi::Constant(rows,4));
	for(int k = 0; k < dimension; k++)
	{
		int fIndex = k; 
		//填充三个分量矩阵
		mat_X.coeffRef(fIndex,fIndex) = beta*faceArea_[fIndex];
		for(int i = 0; i< 3; i++)
		{
			int ffIndex = Faces[fIndex].fIndex[i];//面的三个相邻面
			int feIndex = Faces[fIndex].eIndex[i];//面的三条边的标号
			int fflags = Faces[fIndex].flags[i];//边与面的方向标号
			double e_Length = Edges[feIndex].eLength;//边的长度
			 mat_X.coeffRef( fIndex ,fIndex )  += r*e_Length;
			if(Edges[feIndex].flag != -1)
			{
	     	   mat_X.coeffRef( fIndex ,ffIndex ) = r*e_Length*(-1);
			}
			else ;	
		}
	}
}
void Mesh::pProblem(double alpha1, double r, 
	                    std::vector<double>&grad0,
						std::vector<double>&grad1,
						std::vector<double>&grad2,
						std::vector<double>&lambda_x,
						std::vector<double>&lambda_y,
						std::vector<double>&lambda_z,
						vector<double>&vx,
						vector<double>&vy,
						vector<double>&vz,
						std::vector<double>&px,
						std::vector<double>&py,
						std::vector<double>&pz,
						std::vector<double>&nx,
						std::vector<double>&ny,
						std::vector<double>&nz)
{
	//omp_set_num_threads(NUM_THREADS);
			double w0,w1,w2;
			double theta, wij = 1.;
			double pi = 3.1415926;

		for ( int i = 0; i < eNumber; ++i)
		{ 	
			
				int a = Edges[i].findex[0];      int b = Edges[i].findex[1];
				int flags1 = Edges[i].fflags[0]; int flags2 = Edges[i].fflags[1];
				if(Edges[i].flag != -1)
				{  
					grad0[i] = nx[a]*flags1 + nx[b]*flags2; 
				    grad1[i] = ny[a]*flags1 + ny[b]*flags2; 
				    grad2[i] = nz[a]*flags1 + nz[b]*flags2;
				}
				else
				{
					grad0[i] = 0; 
					grad1[i] = 0; 
					grad2[i] = 0;
				}
		 
				theta = sqrt((nx[a]-nx[b])*(nx[a]-nx[b]) + (ny[a]-ny[b])*(ny[a]-ny[b]) + (nz[a]-nz[b])*(nz[a]-nz[b]));
				
				w0 = grad0[i] -vx[i]- lambda_x[i]/r;  
				w1 = grad1[i] -vy[i]- lambda_y[i]/r;  
				w2 = grad2[i] -vz[i]- lambda_z[i]/r;  
				double ww = sqrt(w0*w0 + w1*w1 + w2*w2);
				wij = 1.*exp(-1.0*pow(theta,2));
				
				if(Edges[i].flag != -1)
				{  
//#pragma omp critical 
					if(ww <= (alpha1*wij)/r)
					{
						px[i] = 0;py[i] = 0;pz[i] = 0;
					}
					//#pragma omp critical
					if(ww> (alpha1*wij)/r)
					{
						
						double t= (1. - (alpha1*wij)/(r*ww));
						px[i] = t*w0;py[i] = t*w1;pz[i] = t*w2;
					}
				}
				else
				{
					px[i] = 0; py[i] = 0; pz[i] = 0;
				}
			}

}




void Mesh::OurDenoisingMethod(double alpha1,double alpha0, double rp ,double rq, double beta, vector<double>&normalx,vector<double>&normaly,vector<double>&normalz)
{
	
	vector<double>gradx(eNumber),grady(eNumber),gradz(eNumber);
    
    int dimension = fNumber;
	vector<double>nx(fNumber),ny(fNumber),nz(fNumber);
	vector<double>nxold(fNumber),nyold(fNumber),nzold(fNumber);
	vector<double> px(eNumber), py(eNumber), pz(eNumber);
	vector<double> lambda_px(eNumber), lambda_py(eNumber), lambda_pz(eNumber);

	vector<double> vx(eNumber,0),vy(eNumber,0),vz(eNumber,0),weight(eNumber,0);	
	vector<double> qx(fNumber),qy(fNumber),qz(fNumber),lambda_qx(fNumber),lambda_qy(fNumber),lambda_qz(fNumber);
	vector<double> div_x(fNumber),div_y(fNumber),div_z(fNumber);
	/*   Parameters setting  */
    
	double stoppingCond, outTole =1e-5;	
	Fnormalx.resize(fNumber);  Fnormaly.resize(fNumber);  Fnormalz.resize(fNumber);
	for (MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		nx[fIndex] = normalx[fIndex];		ny[fIndex] = normaly[fIndex];		        nz[fIndex] = normalz[fIndex];	
		Fnormalx[fIndex] = normalx[fIndex];	Fnormaly[fIndex] = normaly[fIndex];			Fnormalz[fIndex] = normalz[fIndex];	
	}
	for(int i = 0; i < eNumber; ++i)
	{
		px[i] = 0; py[i] = 0;  pz[i] = 0;
		lambda_px[i] = 0;  lambda_py[i] = 0; lambda_pz[i] = 0;
		
	}
	for(int i = 0; i < fNumber; ++i)
	{
	     qx[i] = 0;  lambda_qx[i] = 0;
		 qy[i] = 0;  lambda_qy[i] = 0;
		 qz[i] = 0;  lambda_qz[i] = 0;
		
	}
	

	SparseMatrix<double >mat_N(dimension,dimension),mat_V(eNumber,eNumber);
	mat_N = 0*mat_N;  
	matrix_A(beta,rp,mat_N);//填充矩阵
	mat_N.makeCompressed();
	SimplicialLDLT<SparseMatrix<double>,Eigen::Upper>solver_N;
	solver_N.compute(mat_N); //矩阵分解

	for (int eek = 0; eek < eNumber; eek++)
	{
		int fa = Edges[eek].findex[0];  int fb = Edges[eek].findex[1];
		double ex = normalx[fa]-normalx[fb];
		double ey = normaly[fa]-normaly[fb];
		double ez = normalz[fa]-normalz[fb];
		gradx[eek] = ex; grady[eek] = ey; gradz[eek] = ez;
		    
	}
	     
	
//	//程序开始
	
	int k = 0;
	//do 
    for(int iter = 0; iter < 300; iter++)
    {   
		for (int eek = 0; eek < eNumber; eek++)
			{
				double theta = (gradx[eek]*gradx[eek]+grady[eek]*grady[eek]+gradz[eek]*gradz[eek]);
				weight[eek] =  exp(-1.0*pow(theta,4));
		    }
		  for (int i = 0; i < fNumber; i++)
		  {
			  nxold[i] = nx[i];	nyold[i] = ny[i];	nzold[i] = nz[i];
		  }
		     mat_V = mat_V*0;
	         matrix_V(rp,rq,mat_V,nx,ny,nz,weight);
	         mat_V.makeCompressed();
   	//ConjugateGradient <SparseMatrix<double>>solver_V;
	         SimplicialLDLT<SparseMatrix<double>,Eigen::Upper>solver_V;
	         solver_V.compute(mat_V);	
	
//		  //u_sub problem	
//			clock_t u1,u2; u1 = clock();
		    Eigen::VectorXd Fx(fNumber),Fy(fNumber),Fz(fNumber);
			Eigen::VectorXd x(fNumber),y(fNumber),z(fNumber);
			Fx = Fx*0;  Fy = Fy*0;  Fz = Fz*0;
			x = x*0;    y = y*0;    z = z*0;
			nProblemsolver1(beta, rp,lambda_px,lambda_py,lambda_pz, px, py,pz,
										  normalx,normaly,normalz,Fx,Fy,Fz,vx,vy,vz);

			x = solver_N.solve(Fx);		
            y = solver_N.solve(Fy);
		    z = solver_N.solve(Fz);
			

			for (int i = 0; i < fNumber; i++)
		    {
				int fIndex = i;
				double temp = sqrt(x[fIndex]*x[fIndex]+y[fIndex]*y[fIndex]+z[fIndex]*z[fIndex])+0.000000001;
				Fnormalx[fIndex] = x[fIndex]/temp;	Fnormaly[fIndex] = y[fIndex]/temp;	Fnormalz[fIndex] = z[fIndex]/temp;
				nx[fIndex] = Fnormalx[fIndex];	ny[fIndex] = Fnormaly[fIndex];  nz[fIndex] = Fnormalz[fIndex];
  			}
			//cout<<"begin fill vb "<<endl;
            Eigen::VectorXd Bx(eNumber),By(eNumber),Bz(eNumber);
			Eigen::VectorXd tx(eNumber),ty(eNumber),tz(eNumber);
			Eigen::VectorXd tx0(eNumber),ty0(eNumber),tz0(eNumber);
			Bx = Bx*0;      By = By*0;  Bz = Bz*0;
			tx = tx*0;    ty = ty*0;    tz = tz*0;
			
			Vb(rp, rq, px,py,pz,nx,ny,nz,lambda_px,lambda_py,lambda_pz, gradx,grady, gradz,qx,qy,qz, lambda_qx,lambda_qy,lambda_qz, Bx, By, Bz,weight);
		
			//tx = solver_V.solveWithGuess(Bx,tx0);
			//ty = solver_V.solveWithGuess(By,ty0);
			//tz = solver_V.solveWithGuess(Bz,tz0);
	        tx = solver_V.solve(Bx);
			ty = solver_V.solve(By);
			tz = solver_V.solve(Bz);
			
			for(int i = 0; i < eNumber; i++)
			{
				vx[i] = tx[i]; vy[i] = ty[i]; vz[i] = tz[i]; 
				tx0[i] = vx[i]; ty0[i] = vy[i];  tz0[i] = vz[i];
			
			}
			
			pProblem(alpha1, rp,gradx,grady,gradz,lambda_px,lambda_py,lambda_pz,vx,vy,vz,px,py,pz,nx,ny,nz);
	        q_subproblem(alpha0,rq,div_x,div_y,div_z,qx,qy,qz,lambda_qx,lambda_qy,lambda_qz,vx,vy,vz,nx,ny,nz,weight);

		//*Update Lagrange multipliers (lambda_x,lambda_y,lambda_z).
			for (int eek = 0; eek < eNumber; eek++)
			{
				lambda_px[eek] += rp*(px[eek] - gradx[eek] + vx[eek]);
				lambda_py[eek] += rp*(py[eek] - grady[eek] + vy[eek]);
				lambda_pz[eek] += rp*(pz[eek] - gradz[eek] + vz[eek]);
			}

			for (int fk = 0; fk < fNumber; fk++)
			{
				
				lambda_qx[fk] += rq*(qx[fk] - div_x[fk]);
				lambda_qy[fk] += rq*(qy[fk] - div_y[fk]);
				lambda_qz[fk] += rq*(qz[fk] - div_z[fk]);
			
			}
			//  Compute the stopping condition     
			stoppingCond = 0.0;
		
			for(int i = 0; i < fNumber; ++i)
			{
				stoppingCond += (pow(nx[i] - nxold[i], 2.) + pow(ny[i] - nyold[i], 2.) + pow(nz[i] - nzold[i], 2.))*faceArea_[i]; 
			}
			cout<<" stoppingCond:"<<stoppingCond<<" iter " <<iter<<endl;
			k++;
		//	if(k>300) break;
		
	//}
	}//while (stoppingCond > outTole); 
	for (int i = 0; i < fNumber; i++)
     {
	    	nx[i] = Fnormalx[i];	ny[i] = Fnormaly[i];  nz[i] = Fnormalz[i];
			normalx[i] = nx[i];   normaly[i] = ny[i];   normalz[i] = nz[i];
  	}
	
}



double Mesh::TriangleArea(double *p1,double *p2,double *p3)
{
	double S,d1,d2,d3,d;
	d1 = (p1[1]-p2[1])*(p3[2]-p2[2])-(p3[1]-p2[1])*(p1[2]-p2[2]);
	d2 = (p1[0]-p2[0])*(p3[1]-p2[1])-(p3[0]-p2[0])*(p1[1]-p2[1]);
	d3 = (p1[0]-p2[0])*(p3[2]-p2[2])-(p3[0]-p2[0])*(p1[2]-p2[2]);
	d = sqrt(d1*d1+d2*d2+d3*d3);
	S = 0.5*d;
	return S;
}



 void Mesh::matrix_V(double rp,double rq,SparseMatrix<double> &mat_V,vector<double>&normalx, vector<double>&normaly, vector<double>&normalz,vector<double>&weight)
 {
	 int dimension = eNumber;
	 int rows = dimension;
	 mat_V.setZero();
	 mat_V.reserve(VectorXi::Constant(rows,60));

	 for(int i = 0;  i < eNumber; i++)
	 {
		
		 mat_V.coeffRef(i,i) = rp*Edges[i].eLength;//*weight[i]*weight[i];
	 }
	  for(int i = 0; i < fNumber; i++)
	 {
		 int e0 = Faces[i].eIndex[0]; int e1 = Faces[i].eIndex[1]; int e2 = Faces[i].eIndex[2];
		 int flag0 = Faces[i].flags[0]; int flag1 = Faces[i].flags[1]; int flag2 = Faces[i].flags[2];
		 

		 mat_V.coeffRef(e0,e0) += weight[e0]*weight[e0]*(rq*flag0*Edges[e0].eLength * flag0*Edges[e0].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e0,e1) += weight[e0]*weight[e1]*(rq*flag0*Edges[e0].eLength * flag1*Edges[e1].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e0,e2) += weight[e0]*weight[e2]*(rq*flag0*Edges[e0].eLength * flag2*Edges[e2].eLength)/faceArea_[i];

		 mat_V.coeffRef(e1,e0) += weight[e1]*weight[e0]*(rq*flag1*Edges[e1].eLength * flag0*Edges[e0].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e1,e1) += weight[e1]*weight[e1]*(rq*flag1*Edges[e1].eLength * flag1*Edges[e1].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e1,e2) += weight[e1]*weight[e2]*(rq*flag1*Edges[e1].eLength * flag2*Edges[e2].eLength)/faceArea_[i];

		 mat_V.coeffRef(e2,e0) += weight[e2]*weight[e0]*(rq*flag2*Edges[e2].eLength * flag0*Edges[e0].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e2,e1) += weight[e2]*weight[e1]*(rq*flag2*Edges[e2].eLength * flag1*Edges[e1].eLength)/faceArea_[i];			 
		 mat_V.coeffRef(e2,e2) += weight[e2]*weight[e2]*(rq*flag2*Edges[e2].eLength * flag2*Edges[e2].eLength)/faceArea_[i];
		  
		
	 }
 }


 void Mesh::compute_basis_normal(vector<double>& enx, vector<double>&eny, vector<double>&enz)
 {
	 enx.clear(); eny.clear(); enz.clear();
	 for(int i = 0; i < eNumber; i++)
	 {
		 int a = Edges[i].v1_index; int b = Edges[i].v2_index; 
		 int c = Edges[i].vIndex[0]; int d = Edges[i].vIndex[1];
		 double cx = Points[a].x; double cy = Points[a].y; double cz = Points[a].z;
		 double bx = Points[b].x; double by = Points[b].y; double bz = Points[b].z;
		 double ax = (Points[c].x+Points[d].x)*0.5;
		 double ay = (Points[c].y+Points[d].y)*0.5;
		 double az = (Points[c].z+Points[d].z)*0.5;
		 
		 enx[i] = (ay-cy)*(az-bz)-(az-cz)*(ay-by);
		 eny[i] = (az-cz)*(ax-bx)-(ax-cx)*(az-bz);
		 enz[i] = (ax-cx)*(ay-by)-(ay-cy)*(ax-bx);
		 double Len = enx[i]*enx[i]+eny[i]*eny[i]+enz[i]*enz[i];
		 enx[i] = enx[i]/sqrt(Len);  eny[i] = eny[i]/sqrt(Len);  enz[i] = enz[i]/sqrt(Len);
		// cout<<enx[i]<<"  "<<eny[i]<<"  "<<enz[i]<<endl;
	 }

 }


 void Mesh::Vb(double rp, double rq, vector<double>&px,vector<double>&py,vector<double>&pz,vector<double>&nx,vector<double>&ny,vector<double>&nz,
						 vector<double>&lambda_px,vector<double>&lambda_py,vector<double>&lambda_pz,
						 vector<double>&gradx,vector<double>&grady, vector<double>&gradz,
						 vector<double>&qx,vector<double>&qy,vector<double>&qz,
						 vector<double>&lambda_qx,vector<double>&lambda_qy,vector<double>&lambda_qz,
						  Eigen::VectorXd &bx,  Eigen::VectorXd &by,  Eigen::VectorXd &bz,
						  vector<double>&weight)
 {
	
	 for(int i = 0;  i < eNumber; i++)
	 {
	     
		 int a = Edges[i].findex[0];      int b = Edges[i].findex[1];
		 int flags1 = Edges[i].fflags[0]; int flags2 = Edges[i].fflags[1];		
		 gradx[i] = nx[a]*flags1 + nx[b]*flags2; 
		 grady[i] = ny[a]*flags1 + ny[b]*flags2; 
		 gradz[i] = nz[a]*flags1 + nz[b]*flags2;
		 
		 bx[i] = Edges[i].eLength*(rp*gradx[i]-rp*px[i]-lambda_px[i]);
		 by[i] = Edges[i].eLength*(rp*grady[i]-rp*py[i]-lambda_py[i]);
		 bz[i] = Edges[i].eLength*(rp*gradz[i]-rp*pz[i]-lambda_pz[i]);
		
	 }

	 for(int i = 0; i < fNumber; i++)
	 {
		 int e0 = Faces[i].eIndex[0]; int e1 = Faces[i].eIndex[1]; int e2 = Faces[i].eIndex[2];
		 int flag0 = Faces[i].flags[0]; int flag1 = Faces[i].flags[1]; int flag2 = Faces[i].flags[2];

		 bx[e0] += -(rq*qx[i] + lambda_qx[i])*flag0*Edges[e0].eLength*weight[e0];
		 by[e0] += -(rq*qy[i] + lambda_qy[i])*flag0*Edges[e0].eLength*weight[e0];
		 bz[e0] += -(rq*qz[i] + lambda_qz[i])*flag0*Edges[e0].eLength*weight[e0];
		

		 bx[e1] += -(rq*qx[i] + lambda_qx[i])*flag1*Edges[e1].eLength*weight[e1];
		 by[e1] += -(rq*qy[i] + lambda_qy[i])*flag1*Edges[e1].eLength*weight[e1];
		 bz[e1] += -(rq*qz[i] + lambda_qz[i])*flag1*Edges[e1].eLength*weight[e1];
		
		 bx[e2] += -(rq*qx[i] + lambda_qx[i])*flag2*Edges[e2].eLength*weight[e2];
		 by[e2] += -(rq*qy[i] + lambda_qy[i])*flag2*Edges[e2].eLength*weight[e2];
		 bz[e2] += -(rq*qz[i] + lambda_qz[i])*flag2*Edges[e2].eLength*weight[e2];		  
		
	 }
 }


 void Mesh::q_subproblem(double alpha0, double rq, vector<double> &div_x,vector<double> &div_y,vector<double> &div_z,
	                     vector<double>&qx,vector<double> &qy,vector<double>&qz,
						 vector<double>&lambda_qx,vector<double> &lambda_qy,vector<double> &lambda_qz,
						 vector<double>&vx, vector<double>&vy,vector<double>&vz,
						 vector<double>&nx, vector<double>&ny,vector<double>&nz,vector<double>&weight)
 {
	  for(int i = 0; i < fNumber; i++)
	 {
		 double phi_x = 0, phi_y = 0, phi_z = 0;

		 for(int j = 0; j < 3; j++)
		 {
			 int eindex = Faces[i].eIndex[j];		 int flag = Faces[i].flags[j];
			 int f1 = Edges[eindex].findex[0]; int f2 = Edges[eindex].findex[1]; 
			  if(f1 != -1 && f2 != -1)
		    { 	
			   double theta = sqrt((nx[f1]-nx[f2])*(nx[f1]-nx[f2]) + (ny[f1]-ny[f2])*(ny[f1]-ny[f2])
		                   + (nz[f1]-nz[f2])*(nz[f1]-nz[f2]));
		   }
			 phi_x += -(weight[eindex]*vx[eindex]*flag*Edges[eindex].eLength)/faceArea_[i];
			 phi_y += -(weight[eindex]*vy[eindex]*flag*Edges[eindex].eLength)/faceArea_[i];
			 phi_z += -(weight[eindex]*vz[eindex]*flag*Edges[eindex].eLength)/faceArea_[i];

		 }	
		 div_x[i] = phi_x;	 div_y[i] = phi_y; 	 div_z[i] = phi_z; 
	
	 }
	 for(int i = 0; i < fNumber; i++)
	 {
		 double wx ,wy,wz, ww;
		  wx =  div_x[i]-lambda_qx[i]/rq;
		  wy =  div_y[i]-lambda_qy[i]/rq;		
		  wz =  div_z[i]-lambda_qz[i]/rq;
		  double wk = 1.;
	      ww = sqrt(wx*wx + wy*wy + wz*wz);
		  double ww1 = sqrt(wx*wx);  double ww2 = sqrt(wy*wy);  double ww3 = sqrt(wz*wz);
		
		 if(ww > (alpha0*wk)/rq)
		 {		
			qx[i] = (1.-(alpha0*wk)/(rq*ww))*wx;
			qy[i] = (1.-(alpha0*wk)/(rq*ww))*wy;
			qz[i] = (1.-(alpha0*wk)/(rq*ww))*wz;
	
		 }
		 else
		 {
			qx[i] = 0;	qy[i] = 0;	 qz[i] = 0;
		 }
	
	 }
	
 }


 void Mesh::new_updating_vertex(double v0,double v1, double v2, vector<double>&initial_x, vector<double>&initial_y, vector<double>& initial_z)
 {
	 vector<double> vx(vNumber),vy(vNumber),vz(vNumber);
	  Eigen::VectorXd matF(3*vNumber);
	  Eigen::VectorXd x(3*vNumber);
	  SparseMatrix<double >mat(3*vNumber,3*vNumber);
	  mat = mat*0;
	  mat.reserve(VectorXi::Constant(3*vNumber,60));
	  matrix_vertex(v0,v1,v2,mat);
	  mat.makeCompressed();
	  for(int i = 0; i < vNumber; i++)
	  {
		  matF[i] = v2*initial_x[i]; matF[i+vNumber] = v2*initial_y[i];  matF[i+2*vNumber] = v2*initial_z[i];
	  }
	
	  SimplicialLDLT<SparseMatrix<double>,Eigen::Upper>solver;
	  solver.compute(mat); 
	  x = solver.solve(matF);
	  initial_x.clear(); initial_y.clear(); initial_z.clear();
	   for(MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it!= mesh.vertices_end(); ++v_it)
	  {
		  int vIndex = v_it.handle().idx();
		
		  mesh.point(v_it)[0] = x[vIndex];
		  mesh.point(v_it)[1] = x[vIndex+vNumber];
		  mesh.point(v_it)[2] = x[vIndex+2*vNumber];
		  initial_x[vIndex] = x[vIndex];  initial_y[vIndex] = x[vIndex+vNumber];  initial_z[vIndex] = x[vIndex+2*vNumber];

	  }


 }


 void Mesh::matrix_vertex(double r,double alpha, double beta,SparseMatrix<double >& mat)
 {
	 mat.reserve(VectorXi::Constant(3*vNumber,100));
	 for(int i = 0; i < fNumber; i++)
	{
		int a = Faces[i].a; int b = Faces[i].b; int c = Faces[i].c;
		int a1 = a; int b1 = b; int c1 = c;
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,c) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b+vNumber,a) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,c) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a+vNumber,a) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(b+2*vNumber,b+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,c) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b+2*vNumber,a) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a+2*vNumber,b+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,c) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a+2*vNumber,a) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(c,b+vNumber) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,a+vNumber) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,b+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,a+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,c) += r;
		mat.coeffRef(c,a) += -r/2.;
		mat.coeffRef(c,b) += -r/2.;

		mat.coeffRef(a,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,c) += -r/2.;
		mat.coeffRef(a,a) += r/4.;
		mat.coeffRef(a,b) += r/4.;

		mat.coeffRef(b,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,c) += -r/2.;
		mat.coeffRef(b,a) += r/4.;
		mat.coeffRef(b,b) += r/4.;

		//****************************************//


		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+2*vNumber,a+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(b,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,b) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,c+vNumber) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b,a+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b,b+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,b) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,c+vNumber) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a,a+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a,b+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(c+vNumber,b+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,a+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,b) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,a) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,c+vNumber) += r;
		mat.coeffRef(c+vNumber,a+vNumber) += -r/2.;
		mat.coeffRef(c+vNumber,b+vNumber) += -r/2.;

		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(b+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(b+vNumber,b+vNumber) += r/4.;

		mat.coeffRef(a+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(a+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(a+vNumber,b+vNumber) += r/4.;

		//*******************************************//

		mat.coeffRef(b,b) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,b+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,a+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,c+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b,a+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b,b+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a,b) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,b+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,a+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,c+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a,a+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a,b+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(b+vNumber,b) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,c+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+vNumber,a+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+vNumber,b) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,c+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(c+2*vNumber,b) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,a) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,b+vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,a+vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,c+2*vNumber) += r;
		mat.coeffRef(c+2*vNumber,a+2*vNumber) += -r/2;
		mat.coeffRef(c+2*vNumber,b+2*vNumber) += -r/2;

		mat.coeffRef(a+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += r/4.;

        mat.coeffRef(b+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r/4.;

		int t = b; b = c; c = a; a = t;
		
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,c) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b+vNumber,a) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,c) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a+vNumber,a) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(b+2*vNumber,b+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,c) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b+2*vNumber,a) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a+2*vNumber,b+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,c) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a+2*vNumber,a) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(c,b+vNumber) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,a+vNumber) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,b+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,a+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,c) += r;
		mat.coeffRef(c,a) += -r/2.;
		mat.coeffRef(c,b) += -r/2.;

		mat.coeffRef(a,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,c) += -r/2.;
		mat.coeffRef(a,a) += r/4.;
		mat.coeffRef(a,b) += r/4.;

		mat.coeffRef(b,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,c) += -r/2.;
		mat.coeffRef(b,a) += r/4.;
		mat.coeffRef(b,b) += r/4.;

		//****************************************//


		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+2*vNumber,a+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(b,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,b) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,c+vNumber) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b,a+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b,b+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,b) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,c+vNumber) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a,a+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a,b+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(c+vNumber,b+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,a+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,b) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,a) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,c+vNumber) += r;
		mat.coeffRef(c+vNumber,a+vNumber) += -r/2.;
		mat.coeffRef(c+vNumber,b+vNumber) += -r/2.;

		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(b+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(b+vNumber,b+vNumber) += r/4.;

		mat.coeffRef(a+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(a+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(a+vNumber,b+vNumber) += r/4.;

		//*******************************************//

		mat.coeffRef(b,b) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,b+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,a+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,c+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b,a+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b,b+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a,b) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,b+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,a+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,c+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a,a+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a,b+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(b+vNumber,b) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,c+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+vNumber,a+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+vNumber,b) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,c+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(c+2*vNumber,b) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,a) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,b+vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,a+vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,c+2*vNumber) += r;
		mat.coeffRef(c+2*vNumber,a+2*vNumber) += -r/2;
		mat.coeffRef(c+2*vNumber,b+2*vNumber) += -r/2;

		mat.coeffRef(a+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += r/4.;

        mat.coeffRef(b+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r/4.;

	    t = b; b = c; c = a; a = t;
		
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,c) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b+vNumber,a) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,b) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -r*3*Fnormalz[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,c) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a+vNumber,a) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,b) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(b+2*vNumber,b+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,c) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b+2*vNumber,a) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a+2*vNumber,b+vNumber) += r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*3*Fnormaly[i]*Fnormalz[i]/4;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,c) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a+2*vNumber,a) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(c,b+vNumber) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,a+vNumber) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c,b+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,a+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c,c) += r;
		mat.coeffRef(c,a) += -r/2.;
		mat.coeffRef(c,b) += -r/2.;

		mat.coeffRef(a,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a,c) += -r/2.;
		mat.coeffRef(a,a) += r/4.;
		mat.coeffRef(a,b) += r/4.;

		mat.coeffRef(b,b+vNumber) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,a+vNumber) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b,b+2*vNumber) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,a+2*vNumber) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b,c) += -r/2.;
		mat.coeffRef(b,a) += r/4.;
		mat.coeffRef(b,b) += r/4.;

		//****************************************//


		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b) += r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a) += -r*3*Fnormalz[i]*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+2*vNumber,a+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(b,b+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(b,b) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(b,c+vNumber) += -sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(b,a+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(b,b+vNumber) += sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(a,b+2*vNumber) += r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a+2*vNumber) += -r*3*Fnormalx[i]*Fnormalz[i]/4;
		mat.coeffRef(a,b) += -r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormalz[i]*Fnormalz[i]/4;
		mat.coeffRef(a,c+vNumber) += sqrt(3.)*r*Fnormalz[i]/2;
		mat.coeffRef(a,a+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;
		mat.coeffRef(a,b+vNumber) += -sqrt(3.)*r*Fnormalz[i]/4;

		mat.coeffRef(c+vNumber,b+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,a+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+vNumber,b) += -r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,a) += r*sqrt(3.)*Fnormalz[i]/2;
		mat.coeffRef(c+vNumber,c+vNumber) += r;
		mat.coeffRef(c+vNumber,a+vNumber) += -r/2.;
		mat.coeffRef(c+vNumber,b+vNumber) += -r/2.;

		mat.coeffRef(b+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(b+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(b+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(b+vNumber,b+vNumber) += r/4.;

		mat.coeffRef(a+vNumber,b+2*vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+2*vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b) += r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*sqrt(3.)*Fnormalz[i]/4;
		mat.coeffRef(a+vNumber,c+vNumber) += -r/2.;
		mat.coeffRef(a+vNumber,a+vNumber) += r/4.;
		mat.coeffRef(a+vNumber,b+vNumber) += r/4.;

		//*******************************************//

		mat.coeffRef(b,b) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,a) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(b,b+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,a+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(b,c+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(b,a+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(b,b+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(a,b) += -r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,a) += r*3*Fnormaly[i]*Fnormaly[i]/4;
		mat.coeffRef(a,b+vNumber) += r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,a+vNumber) += -r*3*Fnormaly[i]*Fnormalx[i]/4;
		mat.coeffRef(a,c+2*vNumber) += -sqrt(3.)*r*Fnormaly[i]/2;
		mat.coeffRef(a,a+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;
		mat.coeffRef(a,b+2*vNumber) += sqrt(3.)*r*Fnormaly[i]/4;

		mat.coeffRef(b+vNumber,b) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,a) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(b+vNumber,b+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,a+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,c+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(b+vNumber,a+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(b+vNumber,b+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(a+vNumber,b) += r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,a) += -r*3*Fnormalx[i]*Fnormaly[i]/4;
		mat.coeffRef(a+vNumber,b+vNumber) += -r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,a+vNumber) += r*3*Fnormalx[i]*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,c+2*vNumber) += sqrt(3.)*r*Fnormalx[i]/2;
		mat.coeffRef(a+vNumber,a+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;
		mat.coeffRef(a+vNumber,b+2*vNumber) += -sqrt(3.)*r*Fnormalx[i]/4;

		mat.coeffRef(c+2*vNumber,b) += r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,a) += -r*sqrt(3.)*Fnormaly[i]/2;
		mat.coeffRef(c+2*vNumber,b+vNumber) += -r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,a+vNumber) += r*sqrt(3.)*Fnormalx[i]/2;
		mat.coeffRef(c+2*vNumber,c+2*vNumber) += r;
		mat.coeffRef(c+2*vNumber,a+2*vNumber) += -r/2;
		mat.coeffRef(c+2*vNumber,b+2*vNumber) += -r/2;

		mat.coeffRef(a+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(a+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(a+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(a+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += r/4.;

        mat.coeffRef(b+2*vNumber,b) += -r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,a) += r*sqrt(3.)*Fnormaly[i]/4;
		mat.coeffRef(b+2*vNumber,b+vNumber) += r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,a+vNumber) += -r*sqrt(3.)*Fnormalx[i]/4;
		mat.coeffRef(b+2*vNumber,c+2*vNumber) += -r/2.;
		mat.coeffRef(b+2*vNumber,a+2*vNumber) += r/4.;
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += r/4.;

		//fill constraint 2
           a = a1; b = b1; c = c1;
		mat.coeffRef(b,b) += Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(b,a) += -Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b,b+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(b,a+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b,b+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(b,a+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a,b) += -Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(a,a) += Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a,b+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(a,a+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a,b+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(a,a+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+vNumber,b) += Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+vNumber,a) += -Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+vNumber,b+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+vNumber,a+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+vNumber,b+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+vNumber,a+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+vNumber,b) += -Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+vNumber,a) += Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+vNumber,b+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+vNumber,a+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+vNumber,b+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+vNumber,a+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+2*vNumber,b) += Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+2*vNumber,a) += -Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+2*vNumber,a+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+2*vNumber,a+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+2*vNumber,b) += -Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+2*vNumber,a) += Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+2*vNumber,a+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+2*vNumber,a+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha; 

		 a = b1; b = c1; c = a1;
		mat.coeffRef(b,b) += Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(b,a) += -Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b,b+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(b,a+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b,b+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(b,a+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a,b) += -Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(a,a) += Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a,b+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(a,a+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a,b+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(a,a+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+vNumber,b) += Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+vNumber,a) += -Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+vNumber,b+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+vNumber,a+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+vNumber,b+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+vNumber,a+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+vNumber,b) += -Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+vNumber,a) += Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+vNumber,b+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+vNumber,a+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+vNumber,b+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+vNumber,a+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+2*vNumber,b) += Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+2*vNumber,a) += -Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+2*vNumber,a+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+2*vNumber,a+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+2*vNumber,b) += -Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+2*vNumber,a) += Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+2*vNumber,a+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+2*vNumber,a+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha; 

		 a = c1; b = a1; c = b1;
		mat.coeffRef(b,b) += Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(b,a) += -Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b,b+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(b,a+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b,b+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(b,a+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a,b) += -Fnormalx[i]*Fnormalx[i]*alpha;  mat.coeffRef(a,a) += Fnormalx[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a,b+vNumber) += -Fnormalx[i]*Fnormaly[i]*alpha;  mat.coeffRef(a,a+vNumber) += Fnormalx[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a,b+2*vNumber) += -Fnormalx[i]*Fnormalz[i]*alpha;  mat.coeffRef(a,a+2*vNumber) += Fnormalx[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+vNumber,b) += Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+vNumber,a) += -Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+vNumber,b+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+vNumber,a+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+vNumber,b+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+vNumber,a+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+vNumber,b) += -Fnormaly[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+vNumber,a) += Fnormaly[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+vNumber,b+vNumber) += -Fnormaly[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+vNumber,a+vNumber) += Fnormaly[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+vNumber,b+2*vNumber) += -Fnormaly[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+vNumber,a+2*vNumber) += Fnormaly[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(b+2*vNumber,b) += Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(b+2*vNumber,a) += -Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(b+2*vNumber,a+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(b+2*vNumber,b+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(b+2*vNumber,a+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha; 

		mat.coeffRef(a+2*vNumber,b) += -Fnormalz[i]*Fnormalx[i]*alpha;  mat.coeffRef(a+2*vNumber,a) += Fnormalz[i]*Fnormalx[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+vNumber) += -Fnormalz[i]*Fnormaly[i]*alpha;  mat.coeffRef(a+2*vNumber,a+vNumber) += Fnormalz[i]*Fnormaly[i]*alpha; 
		mat.coeffRef(a+2*vNumber,b+2*vNumber) += -Fnormalz[i]*Fnormalz[i]*alpha;  mat.coeffRef(a+2*vNumber,a+2*vNumber) += Fnormalz[i]*Fnormalz[i]*alpha; 

		}

		for(int i = 0; i < vNumber; i++)
		{
			mat.coeffRef(i,i) += beta;
			mat.coeffRef(i+vNumber,i+vNumber) += beta;
		    mat.coeffRef(i+2*vNumber,i+2*vNumber) += beta;
		}
	
 }


 